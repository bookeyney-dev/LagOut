# LagOut

LagOut is a local Android optimization utility that uses Shizuku to request a limited set of Android shell operations. It has a Jetpack Compose interface, per-game profiles and a manual restore action.

## What it can do

- Force-stop apps the user explicitly selected.
- Temporarily disable the three Android animation scales.
- Request the display's highest reported refresh rate for a game profile.
- Optionally lower the display resolution for a game profile.
- Save the original animation, refresh-rate and display-size settings before the first change, then restore those exact values later.

It cannot guarantee higher FPS, bypass a game's FPS cap, prevent thermal throttling, improve server ping or reopen apps that were force-stopped. Actual results vary by device, Android build and game. Lowering display resolution affects the whole phone until Restore is used. No game files, memory, saves or network traffic are accessed.

## Requirements

- Android 8.0 (API 26) or newer.
- Shizuku installed and its service running.
- Shizuku permission granted to LagOut.

LagOut does not request the Android INTERNET permission and disables Android app backup. Settings and the restore point stay in local DataStore preferences.

## Build locally

Use Android Studio with Android SDK 35 and JDK 17, or run:

```sh
./gradlew assembleDebug
```

The debug APK is written to:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Download an APK on your phone using GitHub Actions

The workflow at `.github/workflows/android-apk.yml` builds a signed debug APK whenever code is pushed to `main` / `master`, or when the workflow is manually started from the repository's **Actions** tab. It publishes the APK in two places:

- **Releases → LagOut latest Android test APK → app-debug.apk** for a direct APK download in an Android browser.
- **Actions → latest successful workflow run → LagOut-Android-APK** as a backup ZIP artifact.

The APK is intended for personal testing and is not a Play Store release build. GitHub-hosted runners may generate a different debug signing key for each run; uninstall the previous debug build before installing an updated APK if Android reports a signature conflict.

## Safety notes

- Review the apps selected in **Settings → Apps to close**. They are force-stopped and are not automatically relaunched.
- Keep Shizuku running while boosting and restoring.
- Use **Restore** after a Quick Boost. When Auto-restore is enabled, LagOut checks whether the game has exited the next time you return to the LagOut screen, then restores the saved settings.
- If Shizuku disconnects, reconnect it before restoring. LagOut keeps the saved restore point until all restore commands succeed.
