# Add project specific ProGuard rules here.
# Shizuku's AIDL-generated classes and our own IUserService.Stub must survive
# minification/R8, since Shizuku looks them up by (class) name when binding.
-keep class com.lagout.booster.IUserService { *; }
-keep class com.lagout.booster.IUserService$Stub { *; }
-keep class com.lagout.booster.shizuku.UserService { *; }
-keep class rikka.shizuku.** { *; }
