// IUserService.aidl
package com.lagout.booster;

// The interface implemented by UserService.kt, which Shizuku runs in a separate process
// under the shell (or root) identity instead of our normal, unprivileged app process.
// Kept deliberately tiny and generic: the main app composes the exact shell command as
// plain text (see boost/BoostCommands.kt) and this just runs it, the same way `adb shell`
// would. Nothing is hardcoded here, so nothing about *what* commands exist needs to live
// in a privileged process.
interface IUserService {

    // Runs `sh -c <command>` and returns its combined stdout+stderr as text.
    String exec(String command);

    // Reserved method Shizuku calls to make the hosted process exit cleanly. The exact
    // transaction code (16777114) is required by Shizuku itself, not something we chose.
    void destroy() = 16777114;
}
