package com.lagout.booster

import android.app.Application
import com.lagout.booster.shizuku.ShizukuManager

class LagOutApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ShizukuManager.init()
    }
}
