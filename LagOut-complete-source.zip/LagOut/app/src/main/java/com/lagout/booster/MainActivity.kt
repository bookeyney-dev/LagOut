package com.lagout.booster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.lagout.booster.shizuku.ShizukuManager
import com.lagout.booster.ui.LagOutNavHost
import com.lagout.booster.ui.theme.LagOutTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LagOutTheme {
                LagOutNavHost()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Shizuku may have just been installed/started/granted while we were away.
        ShizukuManager.checkNow()
    }
}
