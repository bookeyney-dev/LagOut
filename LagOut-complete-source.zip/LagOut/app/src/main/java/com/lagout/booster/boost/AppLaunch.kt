package com.lagout.booster.boost

import android.content.Context
import android.content.Intent

/**
 * Launching another app is ordinary, unprivileged Android — it doesn't need Shizuku at
 * all, so it's kept separate from everything that does.
 */
fun launchApp(context: Context, packageName: String): Boolean {
    if (packageName.isBlank()) return false
    val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try {
        context.startActivity(intent)
        true
    } catch (t: Throwable) {
        false
    }
}

fun isInstalled(context: Context, packageName: String): Boolean {
    if (packageName.isBlank()) return false
    return try {
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (e: Exception) {
        false
    }
}
