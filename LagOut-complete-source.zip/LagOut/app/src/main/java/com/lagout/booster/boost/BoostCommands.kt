package com.lagout.booster.boost

/** The small, explicit set of OS-level commands LagOut can run through Shizuku. */
object BoostCommands {

    // Package names are validated before they are interpolated into shell commands.
    fun forceStop(pkg: String) = "am force-stop $pkg"

    fun readSetting(namespace: String, key: String) = "settings get $namespace $key"
    fun putSetting(namespace: String, key: String, value: String) =
        "settings put $namespace $key $value"
    fun deleteSetting(namespace: String, key: String) = "settings delete $namespace $key"

    fun disableAnimations() = listOf(
        "settings put global window_animation_scale 0",
        "settings put global transition_animation_scale 0",
        "settings put global animator_duration_scale 0",
    )

    fun setPeakRefreshRate(hz: Int) = "settings put system peak_refresh_rate ${hz}.0"
    fun setMinRefreshRate(hz: Int) = "settings put system min_refresh_rate ${hz}.0"

    fun setResolution(widthPx: Int, heightPx: Int) = "wm size ${widthPx}x$heightPx"
    fun resetResolution() = "wm size reset"
    fun currentResolution() = "wm size"
    fun pidOf(pkg: String) = "pidof $pkg"
}
