package com.lagout.booster.boost

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import com.lagout.booster.data.SettingsStore
import com.lagout.booster.shizuku.ShizukuAvailability
import com.lagout.booster.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Runs a carefully limited set of device-level optimizations through Shizuku. */
object BoostEngine {

    data class BoostResult(
        val applied: Boolean,
        val closedApps: List<String>,
        val warnings: List<String>,
    )

    data class RestoreResult(
        val restored: Boolean,
        val hadSnapshot: Boolean,
        val warnings: List<String>,
    )

    private val operationMutex = Mutex()
    private val packageNamePattern = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")
    private val numericSettingPattern = Regex("^(?:\\d+(?:\\.\\d*)?|\\.\\d+)$")
    private val sizePattern = Regex("(\\d+)x(\\d+)")

    suspend fun boost(
        context: Context,
        profile: GameProfile,
        appsToClose: List<String>,
    ): BoostResult = operationMutex.withLock {
        withContext(Dispatchers.IO) {
            val warnings = mutableListOf<String>()
            val closed = mutableListOf<String>()
            var successfulOperations = 0
            val settings = SettingsStore(context)

            if (ShizukuManager.availability.value != ShizukuAvailability.READY) {
                return@withContext BoostResult(
                    applied = false,
                    closedApps = emptyList(),
                    warnings = listOf("Shizuku is not connected. Reconnect it, then try again."),
                )
            }

            // Never replace a session's original snapshot with already-boosted settings.
            val existingSnapshot = settings.activeBoostSnapshot.first()
            if (existingSnapshot == null) {
                val snapshot = captureSnapshot()
                    ?: return@withContext BoostResult(
                        applied = false,
                        closedApps = emptyList(),
                        warnings = listOf("Couldn't read the current device settings. Nothing was changed."),
                    )
                try {
                    settings.saveBoostSnapshot(snapshot)
                } catch (_: Exception) {
                    return@withContext BoostResult(
                        applied = false,
                        closedApps = emptyList(),
                        warnings = listOf("Couldn't save a restore point. Nothing was changed."),
                    )
                }
            }

            if (profile.closeBackgroundApps) {
                appsToClose
                    .filter { it != profile.packageName && it != context.packageName && packageNamePattern.matches(it) }
                    .distinct()
                    .forEach { pkg ->
                        val output = ShizukuManager.run(BoostCommands.forceStop(pkg))
                        if (output.isError()) warnings += "Couldn't close $pkg"
                        else {
                            closed += pkg
                            successfulOperations++
                        }
                    }
            }

            BoostCommands.disableAnimations().forEach {
                if (runOptimization(it, "Couldn't change animation settings", warnings)) {
                    successfulOperations++
                }
            }

            if (profile.forceHighRefreshRate) {
                val maxHz = highestRefreshRate(context)
                if (maxHz != null) {
                    if (runOptimization(BoostCommands.setPeakRefreshRate(maxHz), "Couldn't set the peak refresh rate", warnings)) {
                        successfulOperations++
                    }
                    if (runOptimization(BoostCommands.setMinRefreshRate(maxHz), "Couldn't set the minimum refresh rate", warnings)) {
                        successfulOperations++
                    }
                } else {
                    warnings += "Couldn't read this screen's supported refresh rates"
                }
            }

            if (profile.resolutionScalePercent in 60..99) {
                val applied = applyResolutionScale(profile.resolutionScalePercent)
                if (applied) successfulOperations++
                else warnings += "Couldn't read or change the native resolution, so it was left unchanged"
            }

            if (successfulOperations == 0) {
                warnings += "No optimization command succeeded. The game was not launched; use Restore if needed."
            }
            BoostResult(
                applied = successfulOperations > 0,
                closedApps = closed,
                warnings = warnings.distinct(),
            )
        }
    }

    /** True when [pkg] currently has a running process. */
    suspend fun isRunning(pkg: String): Boolean = withContext(Dispatchers.IO) {
        if (!packageNamePattern.matches(pkg)) return@withContext false
        val output = ShizukuManager.run(BoostCommands.pidOf(pkg))
        !output.isError() && output.trim().firstOrNull()?.isDigit() == true
    }

    /** Restores precisely the settings captured before the first active boost. */
    suspend fun restore(context: Context): RestoreResult = operationMutex.withLock {
        withContext(Dispatchers.IO) {
            val settings = SettingsStore(context)
            val snapshot = try {
                settings.activeBoostSnapshot.first()
            } catch (_: Exception) {
                return@withContext RestoreResult(
                    restored = false,
                    hadSnapshot = false,
                    warnings = listOf("Couldn't read the saved restore point. No device settings were changed."),
                )
            }
            if (snapshot == null) {
                try { settings.setLastBoostedPackage(null) } catch (_: Exception) { }
                return@withContext RestoreResult(
                    restored = true,
                    hadSnapshot = false,
                    warnings = emptyList(),
                )
            }

            if (ShizukuManager.availability.value != ShizukuAvailability.READY) {
                return@withContext RestoreResult(
                    restored = false,
                    hadSnapshot = true,
                    warnings = listOf("Shizuku is not connected. Reconnect it to restore the saved settings."),
                )
            }

            val warnings = mutableListOf<String>()
            restoreSetting("global", "window_animation_scale", snapshot.windowAnimationScale, warnings)
            restoreSetting("global", "transition_animation_scale", snapshot.transitionAnimationScale, warnings)
            restoreSetting("global", "animator_duration_scale", snapshot.animatorDurationScale, warnings)
            restoreSetting("system", "peak_refresh_rate", snapshot.peakRefreshRate, warnings)
            restoreSetting("system", "min_refresh_rate", snapshot.minRefreshRate, warnings)

            val resolutionCommand = snapshot.resolutionOverride?.let { override ->
                val match = sizePattern.matchEntire(override)
                if (match == null) {
                    warnings += "Saved display size was invalid; it was not changed"
                    null
                } else {
                    "wm size ${match.groupValues[1]}x${match.groupValues[2]}"
                }
            } ?: if (snapshot.resolutionOverride == null) BoostCommands.resetResolution() else null
            if (resolutionCommand != null) {
                runOptimization(resolutionCommand, "Couldn't restore the original display size", warnings)
            }

            val success = warnings.isEmpty()
            if (success) {
                try {
                    settings.clearBoostSnapshot()
                    settings.setLastBoostedPackage(null)
                } catch (_: Exception) {
                    warnings += "Device settings were restored, but the saved restore point couldn't be cleared"
                }
            }
            RestoreResult(restored = success && warnings.isEmpty(), hadSnapshot = true, warnings = warnings.distinct())
        }
    }

    private suspend fun captureSnapshot(): SystemSnapshot? {
        suspend fun read(command: String): String? {
            val value = ShizukuManager.run(command)
            if (value.isError()) return null
            return value.trim().lineSequence().firstOrNull()?.ifBlank { "null" } ?: "null"
        }

        val window = read(BoostCommands.readSetting("global", "window_animation_scale")) ?: return null
        val transition = read(BoostCommands.readSetting("global", "transition_animation_scale")) ?: return null
        val animator = read(BoostCommands.readSetting("global", "animator_duration_scale")) ?: return null
        val peak = read(BoostCommands.readSetting("system", "peak_refresh_rate")) ?: return null
        val min = read(BoostCommands.readSetting("system", "min_refresh_rate")) ?: return null
        if (listOf(window, transition, animator, peak, min).any {
                it != "null" && !numericSettingPattern.matches(it)
            }) return null
        val wmOutput = ShizukuManager.run(BoostCommands.currentResolution())
        if (wmOutput.isError()) return null
        val overrideLine = wmOutput.lineSequence().firstOrNull { it.trim().startsWith("Override size:") }
        val override = overrideLine?.let { line -> sizePattern.find(line)?.value }
        if (overrideLine != null && override == null) return null

        return SystemSnapshot(window, transition, animator, peak, min, override)
    }

    private suspend fun restoreSetting(
        namespace: String,
        key: String,
        value: String,
        warnings: MutableList<String>,
    ) {
        val command = if (value == "null" || value.isBlank()) {
            BoostCommands.deleteSetting(namespace, key)
        } else if (numericSettingPattern.matches(value)) {
            BoostCommands.putSetting(namespace, key, value)
        } else {
            warnings += "Saved $key value was invalid; it was not changed"
            return
        }
        runOptimization(command, "Couldn't restore $key", warnings)
    }

    private suspend fun runOptimization(
        command: String,
        warning: String,
        warnings: MutableList<String>,
    ): Boolean {
        val output = ShizukuManager.run(command)
        if (output.isError()) {
            warnings += warning
            return false
        }
        return true
    }

    private fun highestRefreshRate(context: Context): Int? {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display: Display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY) ?: return null
        return display.supportedModes.maxOfOrNull { it.refreshRate }?.roundToInt()?.takeIf { it > 0 }
    }

    private suspend fun applyResolutionScale(percent: Int): Boolean {
        val output = ShizukuManager.run(BoostCommands.currentResolution())
        if (output.isError()) return false
        val physicalLine = output.lineSequence().firstOrNull { it.trim().startsWith("Physical size:") } ?: return false
        val match = sizePattern.find(physicalLine) ?: return false
        val width = match.groupValues[1].toIntOrNull() ?: return false
        val height = match.groupValues[2].toIntOrNull() ?: return false
        val newWidth = evenify(width * percent / 100)
        val newHeight = evenify(height * percent / 100)
        if (newWidth < 320 || newHeight < 320) return false
        val result = ShizukuManager.run(BoostCommands.setResolution(newWidth, newHeight))
        return !result.isError()
    }

    private fun evenify(value: Int) = if (value % 2 == 0) value else value - 1

    private fun String.isError() = startsWith("ERR:", ignoreCase = true)
}
