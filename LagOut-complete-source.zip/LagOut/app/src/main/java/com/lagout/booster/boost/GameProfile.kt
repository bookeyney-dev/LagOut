package com.lagout.booster.boost

/**
 * Per-game settings for a boost run. [id] is a stable key used for persistence (see
 * data/SettingsStore.kt) — it must never change for a given game once shipped, or saved
 * overrides for that game will silently reset to the defaults below.
 */
data class GameProfile(
    val id: String,
    val displayName: String,
    val packageName: String,
    val iconKey: String,
    /** 100 = native resolution. Anything lower is applied via `wm size` before launch. */
    val resolutionScalePercent: Int = 100,
    /** Lock the screen to the highest refresh rate it supports while boosted. */
    val forceHighRefreshRate: Boolean = true,
    /** Close whatever is in the user's "apps to close" list (Settings) before launching. */
    val closeBackgroundApps: Boolean = true,
)

/** Defaults for the four games this build ships with. All of this is user-editable. */
object DefaultGames {

    val BGMI = GameProfile(
        id = "bgmi",
        displayName = "BGMI",
        packageName = "com.pubg.imobile",
        iconKey = "bgmi",
        resolutionScalePercent = 100,
        forceHighRefreshRate = true,
    )

    val ROBLOX = GameProfile(
        id = "roblox",
        displayName = "Roblox",
        packageName = "com.roblox.client",
        iconKey = "roblox",
        resolutionScalePercent = 90,
        forceHighRefreshRate = true,
    )

    val MINECRAFT = GameProfile(
        id = "minecraft",
        displayName = "Minecraft",
        packageName = "com.mojang.minecraftpe",
        iconKey = "minecraft",
        resolutionScalePercent = 90,
        forceHighRefreshRate = false,
    )

    val BLOONS_TD6 = GameProfile(
        id = "bloons_td6",
        displayName = "Bloons TD 6",
        packageName = "com.ninjakiwi.bloonstd6",
        iconKey = "bloons",
        resolutionScalePercent = 100,
        forceHighRefreshRate = false,
    )

    val all = listOf(BGMI, ROBLOX, MINECRAFT, BLOONS_TD6)

    /** Used by the dashboard's "Quick Boost" action, which isn't tied to one game. */
    val QUICK_BOOST = GameProfile(
        id = "quick_boost",
        displayName = "Quick Boost",
        packageName = "",
        iconKey = "bolt",
        resolutionScalePercent = 100,
        forceHighRefreshRate = true,
    )
}
