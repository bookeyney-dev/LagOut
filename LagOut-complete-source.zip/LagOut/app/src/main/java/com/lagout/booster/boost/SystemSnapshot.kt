package com.lagout.booster.boost

/** Exact device settings captured before the first active boost session. */
data class SystemSnapshot(
    val windowAnimationScale: String,
    val transitionAnimationScale: String,
    val animatorDurationScale: String,
    val peakRefreshRate: String,
    val minRefreshRate: String,
    /** Original WM override, or null when Android was using its physical size. */
    val resolutionOverride: String?,
)
