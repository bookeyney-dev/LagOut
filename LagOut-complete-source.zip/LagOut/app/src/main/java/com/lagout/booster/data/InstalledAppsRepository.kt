package com.lagout.booster.data

import android.content.Context
import android.content.Intent

data class AppInfo(
    val packageName: String,
    val label: String,
)

/**
 * Backs the "apps to close" picker (Settings). Reads installed apps through the normal,
 * unprivileged PackageManager — this works even before Shizuku permission is granted,
 * since it's just listing apps, not acting on them.
 */
class InstalledAppsRepository(private val context: Context) {

    fun launchableUserApps(): List<AppInfo> {
        val packageManager = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos = packageManager.queryIntentActivities(launcherIntent, 0)

        return resolveInfos
            .asSequence()
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != context.packageName }
            .map { AppInfo(it.packageName, it.loadLabel(packageManager).toString()) }
            .sortedBy { it.label.lowercase() }
            .toList()
    }
}
