package com.lagout.booster.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.lagout.booster.boost.GameProfile
import com.lagout.booster.boost.SystemSnapshot
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "lagout_settings")

/**
 * The only place LagOut keeps state: which apps to close before a boost, whether to
 * auto-restore on exit, per-game overrides to the compiled-in [GameProfile] defaults,
 * and the exact system settings captured before a boost. All local — there is no
 * account, sync or network layer.
 */
class SettingsStore(private val context: Context) {

    private companion object {
        const val NO_OVERRIDE = "__lagout_no_resolution_override__"
    }

    private object Keys {
        val KILL_LIST = stringSetPreferencesKey("kill_list")
        val AUTO_RESTORE = booleanPreferencesKey("auto_restore_on_exit")
        val LAST_BOOSTED = stringPreferencesKey("last_boosted_package")
        val BOOST_ACTIVE = booleanPreferencesKey("boost_snapshot_active")
        val WINDOW_ANIMATION = stringPreferencesKey("snapshot_window_animation")
        val TRANSITION_ANIMATION = stringPreferencesKey("snapshot_transition_animation")
        val ANIMATOR_DURATION = stringPreferencesKey("snapshot_animator_duration")
        val PEAK_REFRESH = stringPreferencesKey("snapshot_peak_refresh")
        val MIN_REFRESH = stringPreferencesKey("snapshot_min_refresh")
        val RESOLUTION_OVERRIDE = stringPreferencesKey("snapshot_resolution_override")
    }

    private fun resScaleKey(gameId: String) = intPreferencesKey("profile_${gameId}_res_scale")
    private fun highRefreshKey(gameId: String) = booleanPreferencesKey("profile_${gameId}_high_refresh")
    private fun closeAppsKey(gameId: String) = booleanPreferencesKey("profile_${gameId}_close_apps")

    val killList: Flow<Set<String>> =
        context.dataStore.data.map { it[Keys.KILL_LIST] ?: emptySet() }

    val autoRestoreOnExit: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.AUTO_RESTORE] ?: true }

    suspend fun setKillList(packages: Set<String>) {
        context.dataStore.edit { it[Keys.KILL_LIST] = packages }
    }

    suspend fun setAutoRestoreOnExit(value: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_RESTORE] = value }
    }

    /**
     * Package LagOut most recently boosted-and-launched, so that the next time you come
     * back to LagOut it can tell whether that game is still running and, if not, restore
     * automatically. Cleared once that check has run.
     */
    val lastBoostedPackage: Flow<String?> =
        context.dataStore.data.map { it[Keys.LAST_BOOSTED] }

    suspend fun setLastBoostedPackage(packageName: String?) {
        context.dataStore.edit { prefs ->
            if (packageName.isNullOrBlank()) {
                prefs.remove(Keys.LAST_BOOSTED)
            } else {
                prefs[Keys.LAST_BOOSTED] = packageName
            }
        }
    }


    /** A durable snapshot lets Restore work even after LagOut is closed or the phone restarts. */
    val activeBoostSnapshot: Flow<SystemSnapshot?> = context.dataStore.data.map { prefs ->
        if (prefs[Keys.BOOST_ACTIVE] != true) return@map null
        SystemSnapshot(
            windowAnimationScale = prefs[Keys.WINDOW_ANIMATION] ?: "null",
            transitionAnimationScale = prefs[Keys.TRANSITION_ANIMATION] ?: "null",
            animatorDurationScale = prefs[Keys.ANIMATOR_DURATION] ?: "null",
            peakRefreshRate = prefs[Keys.PEAK_REFRESH] ?: "null",
            minRefreshRate = prefs[Keys.MIN_REFRESH] ?: "null",
            resolutionOverride = prefs[Keys.RESOLUTION_OVERRIDE]?.takeUnless { it == NO_OVERRIDE },
        )
    }

    suspend fun saveBoostSnapshot(snapshot: SystemSnapshot) {
        context.dataStore.edit { prefs ->
            prefs[Keys.WINDOW_ANIMATION] = snapshot.windowAnimationScale
            prefs[Keys.TRANSITION_ANIMATION] = snapshot.transitionAnimationScale
            prefs[Keys.ANIMATOR_DURATION] = snapshot.animatorDurationScale
            prefs[Keys.PEAK_REFRESH] = snapshot.peakRefreshRate
            prefs[Keys.MIN_REFRESH] = snapshot.minRefreshRate
            prefs[Keys.RESOLUTION_OVERRIDE] = snapshot.resolutionOverride ?: NO_OVERRIDE
            prefs[Keys.BOOST_ACTIVE] = true
        }
    }

    suspend fun clearBoostSnapshot() {
        context.dataStore.edit { prefs ->
            prefs.remove(Keys.BOOST_ACTIVE)
            prefs.remove(Keys.WINDOW_ANIMATION)
            prefs.remove(Keys.TRANSITION_ANIMATION)
            prefs.remove(Keys.ANIMATOR_DURATION)
            prefs.remove(Keys.PEAK_REFRESH)
            prefs.remove(Keys.MIN_REFRESH)
            prefs.remove(Keys.RESOLUTION_OVERRIDE)
        }
    }

    /** [default]'s values, overridden with anything the user has previously changed. */
    fun profileFor(default: GameProfile): Flow<GameProfile> =
        context.dataStore.data.map { prefs ->
            default.copy(
                resolutionScalePercent = prefs[resScaleKey(default.id)] ?: default.resolutionScalePercent,
                forceHighRefreshRate = prefs[highRefreshKey(default.id)] ?: default.forceHighRefreshRate,
                closeBackgroundApps = prefs[closeAppsKey(default.id)] ?: default.closeBackgroundApps,
            )
        }

    suspend fun saveProfile(profile: GameProfile) {
        context.dataStore.edit { prefs ->
            prefs[resScaleKey(profile.id)] = profile.resolutionScalePercent
            prefs[highRefreshKey(profile.id)] = profile.forceHighRefreshRate
            prefs[closeAppsKey(profile.id)] = profile.closeBackgroundApps
        }
    }
}
