package com.lagout.booster.shizuku

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.lagout.booster.BuildConfig
import com.lagout.booster.IUserService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/** Everything the UI needs to know about whether it can currently run a boost. */
enum class ShizukuAvailability {
    /** Haven't checked yet. */
    UNKNOWN,

    /** The Shizuku app isn't installed, or its service isn't running right now. */
    NOT_RUNNING,

    /** Shizuku is running but LagOut hasn't been granted permission yet. */
    PERMISSION_NEEDED,

    /** The user explicitly denied permission ("don't ask again"). */
    PERMISSION_DENIED,

    /** Granted and bound — boosts can run. */
    READY,
}

/**
 * Process-wide owner of the Shizuku binder and our [IUserService] connection. There is
 * only ever one of each per app process, which is why this is an object rather than a
 * class — every screen just observes [availability] and calls [run] / [requestPermission].
 */
object ShizukuManager {

    private const val REQUEST_CODE = 91010
    private const val SERVICE_TAG = "com.lagout.booster.user_service"

    private val _availability = MutableStateFlow(ShizukuAvailability.UNKNOWN)
    val availability: StateFlow<ShizukuAvailability> = _availability

    @Volatile
    private var userService: IUserService? = null
    private var listenersRegistered = false
    @Volatile
    private var serviceBinding = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshPermissionState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        userService = null
        serviceBinding = false
        _availability.value = ShizukuAvailability.NOT_RUNNING
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    bindService()
                } else {
                    serviceBinding = false
                    userService = null
                    _availability.value = ShizukuAvailability.PERMISSION_DENIED
                }
            }
        }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            serviceBinding = false
            if (binder.pingBinder()) {
                userService = IUserService.Stub.asInterface(binder)
                _availability.value = ShizukuAvailability.READY
            } else {
                userService = null
                _availability.value = ShizukuAvailability.UNKNOWN
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            userService = null
            serviceBinding = false
            _availability.value = ShizukuAvailability.UNKNOWN
        }
    }

    /** Call once, from [com.lagout.booster.LagOutApp.onCreate]. Safe to call more than once. */
    fun init() {
        if (listenersRegistered) return
        listenersRegistered = true
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
    }

    /** Re-checks state. Call from `onResume()` — the user may have just set Shizuku up. */
    fun checkNow() {
        refreshPermissionState()
    }

    fun requestPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                _availability.value = ShizukuAvailability.NOT_RUNNING
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bindService()
                return
            }
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
            userService = null
            serviceBinding = false
            _availability.value = ShizukuAvailability.NOT_RUNNING
        }
    }

    /** Runs one shell command with Shizuku's privilege and returns its output as text. */
    suspend fun run(command: String): String = withContext(Dispatchers.IO) {
        val service = userService
            ?: return@withContext "ERR: Shizuku isn't connected"
        try {
            service.exec(command)
        } catch (t: Throwable) {
            "ERR: ${t.message}"
        }
    }

    private fun refreshPermissionState() {
        try {
            if (!Shizuku.pingBinder()) {
                userService = null
                serviceBinding = false
                _availability.value = ShizukuAvailability.NOT_RUNNING
                return
            }
            if (Shizuku.isPreV11()) {
                // Ancient Shizuku release predating the runtime-permission model.
                _availability.value = ShizukuAvailability.NOT_RUNNING
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bindService()
            } else {
                userService = null
                serviceBinding = false
                _availability.value = ShizukuAvailability.PERMISSION_NEEDED
            }
        } catch (_: Throwable) {
            _availability.value = ShizukuAvailability.NOT_RUNNING
        }
    }

    private fun bindService() {
        if (userService?.asBinder()?.pingBinder() == true) {
            _availability.value = ShizukuAvailability.READY
            return
        }
        if (serviceBinding) return
        val args = Shizuku.UserServiceArgs(
            ComponentName(BuildConfig.APPLICATION_ID, UserService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("boost_service")
            .debuggable(BuildConfig.DEBUG)
            .version(2)
            .tag(SERVICE_TAG)
        try {
            serviceBinding = true
            Shizuku.bindUserService(args, serviceConnection)
        } catch (_: Throwable) {
            serviceBinding = false
            userService = null
            _availability.value = ShizukuAvailability.NOT_RUNNING
        }
    }
}
