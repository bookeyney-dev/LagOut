package com.lagout.booster.shizuku

import com.lagout.booster.IUserService
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.system.exitProcess
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Lives in a separate process that Shizuku launches with shell (or root) privilege —
 * never inside our normal app process. This is the only piece of the app that is able to
 * run commands like `am force-stop`, `settings put global …` or `wm size …`; everything
 * else just asks it to run a command and reads back the text output.
 *
 * It has no logic of its own and makes no decisions — it is intentionally dumb, so that
 * everything worth reading about *what* LagOut does lives in plain Kotlin in the main app
 * process (see boost/BoostCommands.kt and boost/BoostEngine.kt), not hidden in here.
 */
class UserService : IUserService.Stub() {

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            // Drain output concurrently so a command cannot deadlock on a full pipe.
            val capturedOutput = AtomicReference("")
            val reader = Thread {
                capturedOutput.set(
                    BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() },
                )
            }.apply {
                name = "LagOut-shell-output"
                isDaemon = true
                start()
            }

            // LagOut only issues short settings/display/package-manager commands.
            // A timeout prevents a stale shell from leaving a binder call stuck forever.
            val completed = process.waitFor(10, TimeUnit.SECONDS)
            if (!completed) {
                process.destroyForcibly()
                reader.join(1_000)
                return "ERR: command timed out"
            }
            reader.join(1_000)
            if (reader.isAlive) return "ERR: command output timed out"
            val output = capturedOutput.get()
            val exitCode = process.exitValue()
            if (exitCode == 0) output else "ERR: command exited with code $exitCode\n$output"
        } catch (t: Throwable) {
            "ERR: ${t.message}"
        }
    }

    override fun destroy() {
        exitProcess(0)
    }
}
