package com.lagout.booster.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.lagout.booster.ui.about.AboutScreen
import com.lagout.booster.ui.applist.AppPickerScreen
import com.lagout.booster.ui.dashboard.DashboardScreen
import com.lagout.booster.ui.gamedetail.GameDetailScreen
import com.lagout.booster.ui.settings.SettingsScreen

private object Routes {
    const val DASHBOARD = "dashboard"
    const val SETTINGS = "settings"
    const val APP_PICKER = "apps"
    const val ABOUT = "about"
    const val GAME_DETAIL = "game/{gameId}"

    fun gameDetail(gameId: String) = "game/$gameId"
}

@Composable
fun LagOutNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.DASHBOARD) {
        composable(Routes.DASHBOARD) {
            DashboardScreen(
                onOpenGame = { gameId -> navController.navigate(Routes.gameDetail(gameId)) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) },
            )
        }
        composable(Routes.GAME_DETAIL) { backStackEntry ->
            val gameId = backStackEntry.arguments?.getString("gameId") ?: return@composable
            GameDetailScreen(
                gameId = gameId,
                onBack = { navController.popBackStack() },
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onOpenAppPicker = { navController.navigate(Routes.APP_PICKER) },
                onOpenAbout = { navController.navigate(Routes.ABOUT) },
            )
        }
        composable(Routes.APP_PICKER) {
            AppPickerScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.ABOUT) {
            AboutScreen(onBack = { navController.popBackStack() })
        }
    }
}
