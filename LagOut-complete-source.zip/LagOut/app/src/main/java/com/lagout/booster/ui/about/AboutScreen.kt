package com.lagout.booster.ui.about

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lagout.booster.ui.components.SectionHeader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About & setup") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Text(
                text = "LagOut needs Shizuku to do anything beyond showing you this screen. " +
                    "Shizuku is a well-known, open-source Android tool that forwards the same " +
                    "privileged commands `adb shell` can run, to apps you explicitly allow — " +
                    "without rooting your phone.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
            )

            SectionHeader("Setup (one-time)")
            NumberedStep(1, "Install Shizuku", "Install the official Shizuku app from RikkaApps using the download source linked from shizuku.rikka.app.")
            NumberedStep(2, "Start its service", "Open Shizuku and follow its own instructions: pair over \"Wireless debugging\" (Android 11+, no computer needed), a one-time ADB command from a computer, or root if your device is rooted.")
            NumberedStep(3, "Grant LagOut access", "Come back here and tap \"Grant access\" on the home screen. Shizuku will ask you to confirm once.")

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            SectionHeader("What a boost actually does")
            BulletLine("Closes whichever apps you picked in Settings > Apps to close")
            BulletLine("Turns off Android system animations while boosted")
            BulletLine("Can request the screen's highest supported refresh rate for a game")
            BulletLine("Can lower the display resolution; this trades sharpness for a lighter rendering load")
            BulletLine("Saves the original animation, refresh-rate and display-size settings before changing them")

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Text(
                text = "LagOut does not silence notifications, guarantee more FPS, or keep your phone cool. " +
                    "Android and each game decide which frame rates and refresh modes are actually available. " +
                    "The apps you choose under Apps to close are force-stopped; Android does not automatically " +
                    "reopen them afterward.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp),
            )

            SectionHeader("What it can't do")
            Text(
                text = "This is a device-side optimizer, not magic. Closing selected background apps and " +
                    "lowering display resolution may help in some situations, but results depend on the " +
                    "phone, Android version and game. It cannot force a game to unlock 90 FPS, prevent " +
                    "thermal throttling, or change your network connection or server ping. In BGMI or " +
                    "Roblox matches, network lag is between your phone and the game's servers. LagOut " +
                    "doesn't read or modify game files, save data, memory or network traffic.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 16.dp),
            )

            SectionHeader("Privacy")
            Text(
                text = "LagOut requests no INTERNET permission, has no account or analytics system, " +
                    "and Android app backup is disabled. Its preferences and restore point stay in " +
                    "the app's local storage.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 16.dp),
            )

            SectionHeader("Not affiliated with anyone")
            Text(
                text = "LagOut is an independent, unofficial tool. It is not affiliated with, " +
                    "endorsed by, or associated with Krafton, PUBG Studios, Roblox Corporation, " +
                    "Mojang Studios, Microsoft, or Ninja Kiwi. Game names are used only to describe " +
                    "what LagOut is built for.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 24.dp),
            )
        }
    }
}

@Composable
private fun NumberedStep(number: Int, title: String, body: String) {
    Column(modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            text = "$number. $title",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun BulletLine(text: String) {
    Text(
        text = "•  $text",
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(bottom = 4.dp),
    )
}
