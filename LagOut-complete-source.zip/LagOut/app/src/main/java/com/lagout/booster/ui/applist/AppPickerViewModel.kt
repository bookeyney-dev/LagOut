package com.lagout.booster.ui.applist

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lagout.booster.data.AppInfo
import com.lagout.booster.data.InstalledAppsRepository
import com.lagout.booster.data.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

data class AppPickerUiState(
    val apps: List<AppInfo> = emptyList(),
    val selected: Set<String> = emptySet(),
    val query: String = "",
)

class AppPickerViewModel(application: Application) : AndroidViewModel(application) {

    private val settings = SettingsStore(application)
    private val repository = InstalledAppsRepository(application)

    private val _uiState = MutableStateFlow(AppPickerUiState(apps = repository.launchableUserApps()))
    val uiState: StateFlow<AppPickerUiState> = _uiState

    init {
        viewModelScope.launch {
            settings.killList.collect { selected ->
                _uiState.value = _uiState.value.copy(selected = selected)
            }
        }
    }

    fun setQuery(query: String) {
        _uiState.value = _uiState.value.copy(query = query)
    }

    fun toggle(packageName: String) {
        val current = _uiState.value.selected
        val updated = if (packageName in current) current - packageName else current + packageName
        _uiState.value = _uiState.value.copy(selected = updated)
        viewModelScope.launch { settings.setKillList(updated) }
    }
}
