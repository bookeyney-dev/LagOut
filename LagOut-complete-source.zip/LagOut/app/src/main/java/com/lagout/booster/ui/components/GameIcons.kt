package com.lagout.booster.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Adjust
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Maps a [com.lagout.booster.boost.GameProfile.iconKey] to a plain Material icon. LagOut
 * never bundles or draws any game's actual logo — these are deliberately generic stand-ins
 * so there's no question of borrowing anyone else's artwork or mark.
 */
fun iconForKey(key: String): ImageVector = when (key) {
    "bgmi" -> Icons.Filled.GpsFixed
    "roblox" -> Icons.Filled.Widgets
    "minecraft" -> Icons.Filled.Widgets
    "bloons" -> Icons.Filled.Adjust
    "bolt" -> Icons.Filled.Bolt
    else -> Icons.Filled.SportsEsports
}
