package com.lagout.booster.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.lagout.booster.shizuku.ShizukuAvailability

@Composable
fun ShizukuStatusCard(
    availability: ShizukuAvailability,
    onRequestPermission: () -> Unit,
    onRecheck: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (availability == ShizukuAvailability.READY) {
        ReadyRow(modifier)
        return
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusIcon(availability)
                Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                    Text(text = titleFor(availability), style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = subtitleFor(availability),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.End,
            ) {
                when (availability) {
                    ShizukuAvailability.PERMISSION_NEEDED -> Button(onClick = onRequestPermission) {
                        Text("Grant access")
                    }
                    ShizukuAvailability.NOT_RUNNING, ShizukuAvailability.PERMISSION_DENIED -> {
                        OutlinedButton(onClick = onRecheck) { Text("Check again") }
                    }
                    else -> {}
                }
            }
        }
    }
}

@Composable
private fun ReadyRow(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp),
        )
        Text(
            text = "Shizuku ready",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 8.dp),
        )
    }
}

@Composable
private fun StatusIcon(availability: ShizukuAvailability) {
    val (icon, tint) = when (availability) {
        ShizukuAvailability.UNKNOWN -> null to MaterialTheme.colorScheme.onSurfaceVariant
        ShizukuAvailability.NOT_RUNNING -> Icons.Filled.Error to MaterialTheme.colorScheme.error
        ShizukuAvailability.PERMISSION_NEEDED -> Icons.Filled.Lock to MaterialTheme.colorScheme.secondary
        ShizukuAvailability.PERMISSION_DENIED -> Icons.Filled.Warning to MaterialTheme.colorScheme.error
        ShizukuAvailability.READY -> Icons.Filled.CheckCircle to MaterialTheme.colorScheme.primary
    }
    if (icon == null) {
        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
    } else {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape),
        )
    }
}

private fun titleFor(availability: ShizukuAvailability): String = when (availability) {
    ShizukuAvailability.UNKNOWN -> "Checking Shizuku…"
    ShizukuAvailability.NOT_RUNNING -> "Shizuku isn't running"
    ShizukuAvailability.PERMISSION_NEEDED -> "LagOut needs permission"
    ShizukuAvailability.PERMISSION_DENIED -> "Permission denied"
    ShizukuAvailability.READY -> "Shizuku ready"
}

private fun subtitleFor(availability: ShizukuAvailability): String = when (availability) {
    ShizukuAvailability.UNKNOWN -> "One moment."
    ShizukuAvailability.NOT_RUNNING -> "Install Shizuku and start its service, then come back here. See About for the 3-step setup."
    ShizukuAvailability.PERMISSION_NEEDED -> "Grant Shizuku access so a boost can actually change anything."
    ShizukuAvailability.PERMISSION_DENIED -> "Open the Shizuku app, find LagOut in its app list, and allow it manually."
    ShizukuAvailability.READY -> "Boosts can run."
}
