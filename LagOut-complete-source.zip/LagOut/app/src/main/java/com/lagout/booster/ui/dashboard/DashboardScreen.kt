package com.lagout.booster.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lagout.booster.boost.DefaultGames
import com.lagout.booster.boost.GameProfile
import com.lagout.booster.ui.components.GameCard
import com.lagout.booster.ui.components.ShizukuStatusCard
import com.lagout.booster.ui.components.iconForKey
import com.lagout.booster.shizuku.ShizukuAvailability

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onOpenGame: (String) -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: DashboardViewModel = viewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.message) {
        uiState.message?.let { snackbarHostState.showSnackbar(it) }
    }

    val currentViewModel by rememberUpdatedState(viewModel)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                currentViewModel.onResume()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("LagOut") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                },
            )
        },
        snackbarHost = {
            SnackbarHost(snackbarHostState) { data ->
                Snackbar(snackbarData = data, containerColor = MaterialTheme.colorScheme.surfaceVariant)
            }
        },
    ) { padding ->
        DashboardContent(
            padding = padding,
            uiState = uiState,
            onOpenGame = onOpenGame,
            onBoostAndLaunch = viewModel::boostAndLaunch,
            onQuickBoost = viewModel::quickBoost,
            onRestore = viewModel::restoreEverything,
            onRequestPermission = viewModel::requestShizukuPermission,
            onRecheck = viewModel::recheckShizuku,
        )
    }
}

@Composable
private fun DashboardContent(
    padding: PaddingValues,
    uiState: DashboardUiState,
    onOpenGame: (String) -> Unit,
    onBoostAndLaunch: (GameProfile) -> Unit,
    onQuickBoost: () -> Unit,
    onRestore: () -> Unit,
    onRequestPermission: () -> Unit,
    onRecheck: () -> Unit,
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(span = { GridItemSpan(2) }) {
            ShizukuStatusCard(
                availability = uiState.availability,
                onRequestPermission = onRequestPermission,
                onRecheck = onRecheck,
            )
        }

        item(span = { GridItemSpan(2) }) {
            QuickBoostRow(
                busy = uiState.busyGameId != null,
                quickBoostBusy = uiState.busyGameId == DefaultGames.QUICK_BOOST.id,
                enabled = uiState.availability == ShizukuAvailability.READY && uiState.busyGameId == null,
                onQuickBoost = onQuickBoost,
                onRestore = onRestore,
                restoreBusy = uiState.busyGameId != null,
            )
        }

        items(uiState.games, key = { it.profile.id }) { game ->
            GameCard(
                displayName = game.profile.displayName,
                icon = iconForKey(game.profile.iconKey),
                installed = game.installed,
                canBoost = uiState.availability == ShizukuAvailability.READY && uiState.busyGameId == null,
                busy = uiState.busyGameId == game.profile.id,
                onOpenDetail = { onOpenGame(game.profile.id) },
                onBoostAndLaunch = { onBoostAndLaunch(game.profile) },
            )
        }
    }
}

@Composable
private fun QuickBoostRow(
    busy: Boolean,
    quickBoostBusy: Boolean,
    enabled: Boolean,
    restoreBusy: Boolean,
    onQuickBoost: () -> Unit,
    onRestore: () -> Unit,
) {
    Box(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(
                onClick = onQuickBoost,
                enabled = enabled && !busy,
                modifier = Modifier.weight(1f),
            ) {
                Icon(Icons.Filled.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(
                    text = if (quickBoostBusy) "Boosting…" else "Quick Boost",
                    modifier = Modifier.padding(start = 6.dp),
                )
            }
            OutlinedButton(onClick = onRestore, enabled = !restoreBusy) {
                Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(text = "Restore", modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}
