package com.lagout.booster.ui.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lagout.booster.boost.BoostEngine
import com.lagout.booster.boost.DefaultGames
import com.lagout.booster.boost.GameProfile
import com.lagout.booster.boost.isInstalled
import com.lagout.booster.boost.launchApp
import com.lagout.booster.data.SettingsStore
import com.lagout.booster.shizuku.ShizukuAvailability
import com.lagout.booster.shizuku.ShizukuManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.launch

data class GameUiState(
    val profile: GameProfile,
    val installed: Boolean,
)

data class DashboardUiState(
    val availability: ShizukuAvailability = ShizukuAvailability.UNKNOWN,
    val games: List<GameUiState> = emptyList(),
    val busyGameId: String? = null,
    val message: String? = null,
)

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val settings = SettingsStore(application)

    private val _uiState = MutableStateFlow(DashboardUiState(games = installState()))
    val uiState: StateFlow<DashboardUiState> = _uiState

    init {
        viewModelScope.launch {
            ShizukuManager.availability.collect { avail ->
                _uiState.value = _uiState.value.copy(availability = avail, games = installState())
            }
        }
    }

    fun refreshInstalledState() {
        _uiState.value = _uiState.value.copy(games = installState())
    }

    private fun installState(): List<GameUiState> {
        val app = getApplication<Application>()
        return DefaultGames.all.map { profile -> GameUiState(profile, isInstalled(app, profile.packageName)) }
    }

    fun requestShizukuPermission() = ShizukuManager.requestPermission()

    fun recheckShizuku() = ShizukuManager.checkNow()

    fun boostAndLaunch(profile: GameProfile) {
        if (_uiState.value.busyGameId != null) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(busyGameId = profile.id, message = null)
            try {
                val liveProfile = settings.profileFor(profile).first()
                val killList = try { settings.killList.first().toList() } catch (_: Exception) { emptyList() }
                val result = BoostEngine.boost(getApplication(), liveProfile, killList)
                val launched = result.applied && launchApp(getApplication(), liveProfile.packageName)
                if (launched) settings.setLastBoostedPackage(liveProfile.packageName)
                val message = if (!result.applied) {
                    result.warnings.firstOrNull() ?: "Boost couldn't be applied"
                } else {
                    summarize(liveProfile.displayName, result.closedApps.size, launched, result.warnings)
                }
                _uiState.value = _uiState.value.copy(busyGameId = null, message = message)
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(
                    busyGameId = null,
                    message = "Boost failed unexpectedly. Check Shizuku and try again.",
                )
            }
        }
    }

    /** Call when the dashboard comes back to the foreground. */
    fun onResume() {
        refreshInstalledState()
        viewModelScope.launch {
            val autoRestore = try { settings.autoRestoreOnExit.first() } catch (e: Exception) { true }
            if (!autoRestore) return@launch
            val lastPkg = try { settings.lastBoostedPackage.first() } catch (e: Exception) { null }
            if (lastPkg.isNullOrBlank()) return@launch
            val ready = try {
                withTimeoutOrNull(2_500) {
                    ShizukuManager.availability.first { it == ShizukuAvailability.READY }
                }
            } catch (_: Exception) { null }
            if (ready == null) return@launch
            val stillRunning = try { BoostEngine.isRunning(lastPkg) } catch (_: Exception) { true }
            if (!stillRunning) {
                val restore = try { BoostEngine.restore(getApplication()) } catch (_: Exception) { null }
                if (restore?.restored == true) {
                    _uiState.value = _uiState.value.copy(
                        message = if (restore.hadSnapshot) "Game closed — original device settings restored" else null,
                    )
                } else if (restore != null) {
                    _uiState.value = _uiState.value.copy(message = restore.warnings.firstOrNull())
                }
            }
        }
    }

    fun quickBoost() {
        if (_uiState.value.busyGameId != null) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(busyGameId = DefaultGames.QUICK_BOOST.id, message = null)
            try {
                val killList = try { settings.killList.first().toList() } catch (_: Exception) { emptyList() }
                val result = BoostEngine.boost(getApplication(), DefaultGames.QUICK_BOOST, killList)
                val message = if (!result.applied) {
                    result.warnings.firstOrNull() ?: "Quick Boost couldn't be applied"
                } else {
                    summarize("Quick Boost", result.closedApps.size, launched = true, warnings = result.warnings) + " · tap Restore when finished"
                }
                _uiState.value = _uiState.value.copy(busyGameId = null, message = message)
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(
                    busyGameId = null,
                    message = "Quick Boost failed unexpectedly. Check Shizuku and try again.",
                )
            }
        }
    }

    fun restoreEverything() {
        if (_uiState.value.busyGameId != null) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(busyGameId = "restore", message = null)
            val result = try {
                BoostEngine.restore(getApplication())
            } catch (_: Exception) {
                null
            }
            val message = when {
                result == null -> "Restore failed unexpectedly. Check Shizuku and try again."
                !result.restored -> result.warnings.firstOrNull() ?: "Couldn't restore all saved settings"
                !result.hadSnapshot -> "No saved boost session to restore"
                else -> "Restored your original device settings"
            }
            _uiState.value = _uiState.value.copy(busyGameId = null, message = message)
        }
    }

    private fun summarize(name: String, closedCount: Int, launched: Boolean, warnings: List<String>): String =
        buildString {
            append("Boosted $name")
            if (closedCount > 0) append(" · closed $closedCount app(s)")
            if (!launched) append(" · couldn't auto-launch it")
            if (warnings.isNotEmpty()) append(" · ${warnings.first()}")
        }
}
