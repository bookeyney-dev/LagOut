package com.lagout.booster.ui.gamedetail

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lagout.booster.ui.components.PercentSliderRow
import com.lagout.booster.ui.components.SectionHeader
import com.lagout.booster.ui.components.SwitchRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameDetailScreen(
    gameId: String,
    onBack: () -> Unit,
    viewModel: GameDetailViewModel = viewModel(),
) {
    LaunchedEffect(gameId) { viewModel.load(gameId) }
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentViewModel by rememberUpdatedState(viewModel)
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) currentViewModel.onResume()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(uiState?.message) {
        uiState?.message?.let { snackbarHostState.showSnackbar(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(uiState?.profile?.displayName ?: "") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        snackbarHost = {
            SnackbarHost(snackbarHostState) { data ->
                Snackbar(snackbarData = data, containerColor = MaterialTheme.colorScheme.surfaceVariant)
            }
        },
    ) { padding ->
        val state = uiState
        if (state == null) {
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Text(
                text = if (state.installed) state.profile.packageName else "Not installed on this device",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
            )

            SectionHeader("What a boost does for this game")

            SwitchRow(
                title = "Request highest refresh rate",
                subtitle = "Requests the screen's highest supported refresh rate. Android or the game may still limit it.",
                checked = state.profile.forceHighRefreshRate,
                onCheckedChange = { checked ->
                    viewModel.updateProfile { it.copy(forceHighRefreshRate = checked) }
                },
            )

            HorizontalDivider()

            PercentSliderRow(
                title = "Display resolution",
                percent = state.profile.resolutionScalePercent,
                onPercentChange = { percent ->
                    viewModel.updateProfile { it.copy(resolutionScalePercent = percent) }
                },
            )
            Text(
                text = "Below 100% trades sharpness for a lighter rendering load. It changes the phone display for all apps until Restore.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            HorizontalDivider(modifier = Modifier.padding(top = 8.dp))

            SwitchRow(
                title = "Close background apps first",
                subtitle = "Force-stops whatever you picked in Settings > Apps to close.",
                checked = state.profile.closeBackgroundApps,
                onCheckedChange = { checked ->
                    viewModel.updateProfile { it.copy(closeBackgroundApps = checked) }
                },
            )

            HorizontalDivider()

            Button(
                onClick = viewModel::boostAndLaunch,
                enabled = !state.busy,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
            ) {
                if (state.busy) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Text(if (state.installed) "Boost & Launch" else "Boost (install the game to launch it)")
                }
            }
        }
    }
}
