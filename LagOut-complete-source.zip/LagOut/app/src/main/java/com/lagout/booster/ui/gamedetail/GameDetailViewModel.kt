package com.lagout.booster.ui.gamedetail

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lagout.booster.boost.BoostEngine
import com.lagout.booster.boost.DefaultGames
import com.lagout.booster.boost.GameProfile
import com.lagout.booster.boost.isInstalled
import com.lagout.booster.boost.launchApp
import com.lagout.booster.data.SettingsStore
import com.lagout.booster.shizuku.ShizukuAvailability
import com.lagout.booster.shizuku.ShizukuManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.launch

data class GameDetailUiState(
    val profile: GameProfile,
    val installed: Boolean,
    val busy: Boolean = false,
    val message: String? = null,
)

class GameDetailViewModel(application: Application) : AndroidViewModel(application) {

    private val settings = SettingsStore(application)
    private var loadedGameId: String? = null

    private val _uiState = MutableStateFlow<GameDetailUiState?>(null)
    val uiState: StateFlow<GameDetailUiState?> = _uiState

    fun load(gameId: String) {
        if (loadedGameId == gameId) return
        loadedGameId = gameId
        val default = DefaultGames.all.firstOrNull { it.id == gameId } ?: return
        viewModelScope.launch {
            val profile = settings.profileFor(default).first()
            val installed = isInstalled(getApplication(), profile.packageName)
            _uiState.value = GameDetailUiState(profile, installed)
        }
    }

    /** Auto-restore is checked when the user returns to LagOut, including from a game detail screen. */
    fun onResume() {
        viewModelScope.launch {
            val autoRestore = try { settings.autoRestoreOnExit.first() } catch (_: Exception) { true }
            if (!autoRestore) return@launch
            val lastPackage = try { settings.lastBoostedPackage.first() } catch (_: Exception) { null }
            if (lastPackage.isNullOrBlank()) return@launch
            val ready = try {
                withTimeoutOrNull(2_500) {
                    ShizukuManager.availability.first { it == ShizukuAvailability.READY }
                }
            } catch (_: Exception) { null }
            if (ready == null) return@launch
            val stillRunning = try { BoostEngine.isRunning(lastPackage) } catch (_: Exception) { true }
            if (!stillRunning) {
                val result = try { BoostEngine.restore(getApplication()) } catch (_: Exception) { null }
                val message = when {
                    result == null -> "Auto-restore failed. Reconnect Shizuku and use Restore."
                    !result.restored -> result.warnings.firstOrNull() ?: "Auto-restore couldn't finish"
                    result.hadSnapshot -> "Game closed — original device settings restored"
                    else -> null
                }
                _uiState.value = _uiState.value?.copy(message = message)
            }
        }
    }

    fun updateProfile(transform: (GameProfile) -> GameProfile) {
        val current = _uiState.value ?: return
        val updated = transform(current.profile)
        _uiState.value = current.copy(profile = updated)
        viewModelScope.launch { settings.saveProfile(updated) }
    }

    fun boostAndLaunch() {
        val current = _uiState.value ?: return
        if (current.busy) return
        viewModelScope.launch {
            _uiState.value = current.copy(busy = true, message = null)
            val killList = try {
                settings.killList.first().toList()
            } catch (e: Exception) {
                emptyList()
            }
            val result = try {
                BoostEngine.boost(getApplication(), current.profile, killList)
            } catch (_: Exception) {
                null
            }
            val launched = result?.applied == true && launchApp(getApplication(), current.profile.packageName)
            if (launched) {
                try { settings.setLastBoostedPackage(current.profile.packageName) } catch (_: Exception) { }
            }
            val msg = when {
                result == null -> "Boost failed unexpectedly. Check Shizuku and try again."
                !result.applied -> result.warnings.firstOrNull() ?: "Boost couldn't be applied"
                else -> buildString {
                    append("Boosted ${current.profile.displayName}")
                    if (result.closedApps.isNotEmpty()) append(" · closed ${result.closedApps.size} app(s)")
                    if (!launched) append(if (current.installed) " · couldn't launch the game" else " · install the game to auto-launch it")
                    if (result.warnings.isNotEmpty()) append(" · ${result.warnings.first()}")
                }
            }
            _uiState.value = (_uiState.value ?: current).copy(busy = false, message = msg)
        }
    }
}
