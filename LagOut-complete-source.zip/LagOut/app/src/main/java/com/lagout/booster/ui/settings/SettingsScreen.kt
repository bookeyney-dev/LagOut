package com.lagout.booster.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lagout.booster.data.SettingsStore
import com.lagout.booster.ui.components.NavRow
import com.lagout.booster.ui.components.SectionHeader
import com.lagout.booster.ui.components.SwitchRow
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenAppPicker: () -> Unit,
    onOpenAbout: () -> Unit,
) {
    val context = LocalContext.current
    val settings = remember { SettingsStore(context) }
    val scope = rememberCoroutineScope()

    val autoRestore by settings.autoRestoreOnExit.collectAsState(initial = true)
    val killList by settings.killList.collectAsState(initial = emptySet())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp),
        ) {
            SectionHeader("Behavior")
            SwitchRow(
                title = "Auto-restore",
                subtitle = "Next time you open LagOut after the boosted game has closed, undo the tweaks automatically.",
                checked = autoRestore,
                onCheckedChange = { checked -> scope.launch { settings.setAutoRestoreOnExit(checked) } },
            )

            HorizontalDivider()
            SectionHeader("Apps")
            NavRow(
                title = "Apps to close",
                subtitle = "${killList.size} selected — closed before every boost",
                onClick = onOpenAppPicker,
            )

            HorizontalDivider()
            SectionHeader("Help")
            NavRow(
                title = "About & Shizuku setup",
                subtitle = "What this app can and can't do, and how to connect Shizuku",
                onClick = onOpenAbout,
            )
        }
    }
}
