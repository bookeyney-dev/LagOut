package com.lagout.booster.ui.theme

import androidx.compose.ui.graphics.Color

// Dark palette (default — this app is built dark-first, like most gaming tools).
val DarkBackground = Color(0xFF0B0D10)
val DarkSurface = Color(0xFF14171C)
val DarkSurfaceVariant = Color(0xFF1C2026)
val DarkOutline = Color(0xFF2A2F37)
val DarkOnBackground = Color(0xFFEDEFF2)
val DarkOnSurfaceVariant = Color(0xFF9AA3AE)

val BoostGreen = Color(0xFF35E07A)
val OnBoostGreen = Color(0xFF06120B)
val EmberAmber = Color(0xFFFFB648)
val OnEmberAmber = Color(0xFF2B1800)
val DarkError = Color(0xFFFF6B6B)

// Light palette (used automatically when the system is in light mode).
val LightBackground = Color(0xFFF7F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEDEFF2)
val LightOutline = Color(0xFFD0D5DC)
val LightOnBackground = Color(0xFF14171C)
val LightOnSurfaceVariant = Color(0xFF4B5563)

val BoostGreenOnLight = Color(0xFF1F9D53)
val EmberAmberOnLight = Color(0xFFB4690E)
val LightError = Color(0xFFBA1A1A)
