package com.lagout.booster.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LagOutDarkColors = darkColorScheme(
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnBackground,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline,
    primary = BoostGreen,
    onPrimary = OnBoostGreen,
    primaryContainer = DarkSurfaceVariant,
    onPrimaryContainer = BoostGreen,
    secondary = EmberAmber,
    onSecondary = OnEmberAmber,
    error = DarkError,
    onError = OnBoostGreen,
)

private val LagOutLightColors = lightColorScheme(
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnBackground,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    primary = BoostGreenOnLight,
    onPrimary = LightSurface,
    primaryContainer = LightSurfaceVariant,
    onPrimaryContainer = BoostGreenOnLight,
    secondary = EmberAmberOnLight,
    onSecondary = LightSurface,
    error = LightError,
    onError = LightSurface,
)

/**
 * Deliberately does NOT use dynamic color (Material You). A gaming-performance tool reads
 * as more deliberate and "tuned" with its own fixed palette than with a scheme borrowed
 * from the user's wallpaper on Android 12+.
 */
@Composable
fun LagOutTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) LagOutDarkColors else LagOutLightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = LagOutTypography,
        content = content,
    )
}
